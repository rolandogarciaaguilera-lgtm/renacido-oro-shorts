# Renacido Oro — Fábrica automática V2

Este paquete crea un Short original de 1080 × 1920 con voz neural en español,
lo sube a YouTube y envía una copia con el enlace a Telegram.

## Funcionamiento

1. GitHub Actions se activa una vez al día.
2. El sistema elige un tema del catálogo.
3. Genera imágenes, movimiento y voz neural masculina.
4. Ensambla un MP4 vertical de alta resolución.
5. Si YouTube está autorizado, lo publica automáticamente.
6. Envía el video y el enlace al bot privado de Telegram.

El usuario no tiene que fabricar ni subir cada video. Solo debe completar una
autorización inicial del canal de YouTube.

## Secretos necesarios en GitHub

Telegram:

- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

YouTube:

- `YOUTUBE_CLIENT_ID`
- `YOUTUBE_CLIENT_SECRET`
- `YOUTUBE_REFRESH_TOKEN`

La variable `YOUTUBE_PRIVACY_STATUS` debe mantenerse en `private` durante las
pruebas. Cuando la calidad esté aprobada puede cambiarse a `public`.

## Seguridad y calidad

- No almacena contraseñas dentro del código.
- Los tokens se guardan únicamente como secretos de GitHub.
- Cada ejecución produce un video original desde el catálogo.
- La voz principal es `es-CU-ManuelNeural`; usa una voz alternativa si falla.
- El flujo se limita a un video diario para evitar publicación masiva repetitiva.
- La monetización nunca está garantizada y depende de las políticas y revisión
  de YouTube.
