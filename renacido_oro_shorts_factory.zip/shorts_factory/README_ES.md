# Renacido Oro — Fábrica gratuita de Shorts

Este paquete crea un video vertical de 720 × 1280, añade narración en español y
lo envía al bot privado de Telegram. No descarga videos ajenos, no usa música
con copyright y no promete ganancias.

## Qué hace

1. Recibe uno de los temas aprobados del catálogo.
2. Genera tres escenas verticales con texto original.
3. Crea una narración local con `espeak-ng`.
4. Une todo en un MP4 con FFmpeg.
5. Envía el resultado a Telegram.

## Temas iniciales

- `ia_trabajo`
- `testing_remoto`
- `seguridad_estafas`

## Configuración en GitHub

El repositorio necesita dos secretos en **Settings → Secrets and variables →
Actions**:

- `TELEGRAM_BOT_TOKEN`: token vigente del bot. Nunca debe publicarse.
- `TELEGRAM_CHAT_ID`: identificador numérico del propietario.

Después, abre **Actions → Crear Short y enviarlo a Telegram → Run workflow**,
selecciona un tema y ejecuta la prueba.

## Seguridad

- Los secretos no aparecen en el código.
- El flujo solo lee el repositorio.
- El trabajo tiene un límite de 12 minutos.
- El video se envía únicamente al chat configurado.
- No publiques automáticamente antes de revisar el resultado y sus datos.

## Próxima conexión

Cuando la prueba manual funcione, el Worker de Cloudflare podrá llamar el evento
`repository_dispatch`. Así, el comando `/crear tema` iniciará el proceso sin
entrar en GitHub.
