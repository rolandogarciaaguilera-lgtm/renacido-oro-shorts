#!/usr/bin/env python3
"""Sube el Short terminado a YouTube con OAuth 2.0 y un token renovable."""

from __future__ import annotations

import json
import os
import random
import time
from pathlib import Path

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload


ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "output"
VIDEO_PATH = OUTPUT_DIR / "short.mp4"
METADATA_PATH = OUTPUT_DIR / "metadata.json"
RESULT_PATH = OUTPUT_DIR / "youtube_result.json"
UPLOAD_SCOPE = "https://www.googleapis.com/auth/youtube.upload"
RETRIABLE_STATUS_CODES = {500, 502, 503, 504}


def required(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"Falta el secreto {name}")
    return value


def main() -> None:
    if not VIDEO_PATH.exists() or not METADATA_PATH.exists():
        raise FileNotFoundError("Primero ejecuta generate_short.py")

    metadata = json.loads(METADATA_PATH.read_text(encoding="utf-8"))
    privacy = os.environ.get("YOUTUBE_PRIVACY_STATUS", "private").strip().lower()
    if privacy not in {"private", "unlisted", "public"}:
        raise ValueError("YOUTUBE_PRIVACY_STATUS debe ser private, unlisted o public")

    credentials = Credentials(
        token=None,
        refresh_token=required("YOUTUBE_REFRESH_TOKEN"),
        token_uri="https://oauth2.googleapis.com/token",
        client_id=required("YOUTUBE_CLIENT_ID"),
        client_secret=required("YOUTUBE_CLIENT_SECRET"),
        scopes=[UPLOAD_SCOPE],
    )
    youtube = build("youtube", "v3", credentials=credentials, cache_discovery=False)

    title = f'{metadata["title"]} #Shorts'[:100]
    hashtags = " ".join(metadata.get("hashtags", []))
    description = (
        f'{metadata.get("description", "")}\n\n'
        f"{hashtags}\n\n"
        "Contenido educativo original de Renacido Oro."
    )[:5000]
    body = {
        "snippet": {
            "title": title,
            "description": description,
            "tags": [tag.lstrip("#") for tag in metadata.get("hashtags", [])],
            "categoryId": "27",
            "defaultLanguage": "es",
        },
        "status": {
            "privacyStatus": privacy,
            "selfDeclaredMadeForKids": False,
        },
    }
    media = MediaFileUpload(
        str(VIDEO_PATH),
        mimetype="video/mp4",
        chunksize=8 * 1024 * 1024,
        resumable=True,
    )
    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=media,
        notifySubscribers=False,
    )

    response = None
    attempt = 0
    while response is None:
        try:
            _, response = request.next_chunk()
        except HttpError as error:
            if error.resp.status not in RETRIABLE_STATUS_CODES or attempt >= 5:
                raise
            attempt += 1
            time.sleep(random.uniform(1, 2**attempt))

    video_id = response["id"]
    result = {
        "video_id": video_id,
        "url": f"https://youtu.be/{video_id}",
        "privacy_status": privacy,
        "title": title,
    }
    RESULT_PATH.write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
