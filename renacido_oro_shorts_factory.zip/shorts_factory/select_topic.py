#!/usr/bin/env python3
"""Elige un tema de forma determinista para que el horario diario sea automático."""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
catalog = json.loads((ROOT / "catalog.json").read_text(encoding="utf-8"))
topics = sorted(catalog["topics"])
if not topics:
    raise SystemExit("El catálogo no contiene temas")
day_number = dt.datetime.now(dt.timezone.utc).date().toordinal()
print(topics[day_number % len(topics)])
