#!/usr/bin/env python3
"""Genera Shorts verticales originales con voz neural y diseño cinematográfico."""

from __future__ import annotations

import argparse
import json
import math
import random
import shutil
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont


ROOT = Path(__file__).resolve().parent
CATALOG_PATH = ROOT / "catalog.json"
BUILD_DIR = ROOT / "build"
OUTPUT_DIR = ROOT / "output"
WIDTH, HEIGHT, FPS = 1080, 1920, 30
FONT_REGULAR = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
FONT_BOLD = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
PRIMARY_VOICE = "es-CU-ManuelNeural"
BACKUP_VOICE = "es-MX-JorgeNeural"


def run(command: list[str]) -> None:
    subprocess.run(command, check=True)


def duration(path: Path) -> float:
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(path),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return float(result.stdout.strip())


def font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    if not path.exists():
        raise FileNotFoundError(f"No se encontró la fuente: {path}")
    return ImageFont.truetype(str(path), size=size)


def rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return tuple(int(value[i : i + 2], 16) for i in (0, 2, 4))


def vertical_gradient(
    top: tuple[int, int, int], bottom: tuple[int, int, int]
) -> Image.Image:
    strip = Image.new("RGB", (1, HEIGHT))
    pixels = strip.load()
    for y in range(HEIGHT):
        ratio = y / max(1, HEIGHT - 1)
        pixels[0, y] = tuple(
            int(top[channel] * (1 - ratio) + bottom[channel] * ratio)
            for channel in range(3)
        )
    return strip.resize((WIDTH, HEIGHT))


def wrap_pixels(
    text: str, text_font: ImageFont.FreeTypeFont, max_width: int
) -> list[str]:
    words = text.strip().split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = word if not current else f"{current} {word}"
        box = text_font.getbbox(candidate)
        if box[2] - box[0] <= max_width:
            current = candidate
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def fitted_lines(
    text: str,
    font_path: Path,
    start_size: int,
    min_size: int,
    max_width: int,
    max_lines: int,
) -> tuple[ImageFont.FreeTypeFont, list[str]]:
    for size in range(start_size, min_size - 1, -2):
        text_font = font(font_path, size)
        lines = wrap_pixels(text, text_font, max_width)
        if len(lines) <= max_lines:
            return text_font, lines
    text_font = font(font_path, min_size)
    lines = wrap_pixels(text, text_font, max_width)[:max_lines]
    if lines:
        lines[-1] = lines[-1].rstrip(" .") + "…"
    return text_font, lines


def draw_lines(
    draw: ImageDraw.ImageDraw,
    lines: list[str],
    x: int,
    y: int,
    text_font: ImageFont.FreeTypeFont,
    fill: tuple[int, ...],
    gap: int,
    last_fill: tuple[int, ...] | None = None,
) -> int:
    for line_index, line in enumerate(lines):
        line_fill = last_fill if last_fill and line_index == len(lines) - 1 else fill
        draw.text((x, y), line, font=text_font, fill=line_fill)
        box = draw.textbbox((x, y), line, font=text_font)
        y += (box[3] - box[1]) + gap
    return y


def make_slide(
    destination: Path,
    slide: dict,
    index: int,
    total: int,
    palette: list[str],
    seed: int,
    topic_title: str,
    topic_tag: str,
) -> None:
    rng = random.Random(seed)
    background_top = rgb(palette[0])
    background_bottom = rgb(palette[1])
    gold = rgb(palette[2])
    cyan = rgb(palette[3])

    image = vertical_gradient(background_top, background_bottom).convert("RGBA")

    glow = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    glow_draw = ImageDraw.Draw(glow)
    glow_draw.ellipse((-300, -180, 630, 750), fill=(*cyan, 42))
    glow_draw.ellipse((550, 820, 1450, 1850), fill=(*gold, 32))
    image = Image.alpha_composite(image, glow.filter(ImageFilter.GaussianBlur(125)))

    decoration = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    deco = ImageDraw.Draw(decoration)
    for offset in range(-HEIGHT, WIDTH + HEIGHT, 150):
        deco.line(
            (offset, 0, offset - HEIGHT, HEIGHT),
            fill=(255, 255, 255, 10),
            width=2,
        )
    for _ in range(10):
        radius = rng.randint(4, 12)
        x = rng.randint(55, WIDTH - 55)
        y = rng.randint(300, HEIGHT - 250)
        deco.ellipse(
            (x - radius, y - radius, x + radius, y + radius),
            fill=(*cyan, 34),
        )

    number_font = font(FONT_BOLD, 360)
    number = f"{index:02d}"
    number_box = deco.textbbox((0, 0), number, font=number_font)
    deco.text(
        (WIDTH - (number_box[2] - number_box[0]) - 20, 205),
        number,
        font=number_font,
        fill=(255, 255, 255, 18),
    )
    image = Image.alpha_composite(image, decoration)
    draw = ImageDraw.Draw(image)

    brand_font = font(FONT_BOLD, 34)
    small_font = font(FONT_BOLD, 28)
    tiny_font = font(FONT_REGULAR, 25)
    body_font, body_lines = fitted_lines(
        slide["body"], FONT_REGULAR, 52, 42, WIDTH - 170, 4
    )
    heading_font, heading_lines = fitted_lines(
        slide["heading"].upper(), FONT_BOLD, 112, 78, WIDTH - 160, 4
    )

    draw.ellipse((72, 86, 96, 110), fill=gold)
    draw.text((118, 76), "RENACIDO ORO", font=brand_font, fill=(248, 249, 252))
    draw.text((76, 175), topic_tag.upper(), font=small_font, fill=(*cyan, 255))
    draw.line((76, 242, WIDTH - 76, 242), fill=(255, 255, 255, 35), width=2)

    counter = f"IDEA {index}  /  {total}"
    draw.rounded_rectangle((76, 332, 320, 398), radius=32, fill=(*gold, 235))
    draw.text((108, 347), counter, font=small_font, fill=(10, 16, 28))

    y = draw_lines(
        draw,
        heading_lines,
        76,
        520,
        heading_font,
        (248, 249, 252),
        22,
        last_fill=(*gold, 255),
    )
    y += 46
    draw.rounded_rectangle((76, y, 188, y + 10), radius=5, fill=gold)
    y += 74
    draw_lines(draw, body_lines, 76, y, body_font, (211, 222, 237), 20)

    card_top = 1490
    draw.rounded_rectangle(
        (76, card_top, WIDTH - 76, card_top + 190),
        radius=38,
        fill=(5, 12, 25, 205),
        outline=(*gold, 150),
        width=3,
    )
    draw.text((116, card_top + 35), "ACCIÓN", font=tiny_font, fill=(*gold, 255))
    action_font, action_lines = fitted_lines(
        slide["action"].upper(), FONT_BOLD, 42, 34, WIDTH - 235, 2
    )
    draw_lines(
        draw,
        action_lines,
        116,
        card_top + 82,
        action_font,
        (248, 249, 252),
        10,
    )

    progress_y = 1770
    for dot_index in range(total):
        x = 76 + dot_index * 54
        fill = gold if dot_index < index else (255, 255, 255, 55)
        draw.rounded_rectangle(
            (x, progress_y, x + 38, progress_y + 10), radius=5, fill=fill
        )
    footer_font, footer_lines = fitted_lines(
        topic_title.upper(), FONT_REGULAR, 24, 20, 680, 1
    )
    footer_width = draw.textbbox(
        (0, 0), footer_lines[0], font=footer_font
    )[2]
    draw.text(
        (WIDTH - footer_width - 76, progress_y - 10),
        footer_lines[0],
        font=footer_font,
        fill=(170, 184, 204),
    )

    image.convert("RGB").save(destination, quality=96, subsampling=0)


def narration(text: str, destination: Path) -> str:
    executable = shutil.which("edge-tts")
    if not executable:
        raise RuntimeError("Falta edge-tts. Instala requirements.txt.")

    errors: list[str] = []
    for voice in (PRIMARY_VOICE, BACKUP_VOICE):
        if destination.exists():
            destination.unlink()
        result = subprocess.run(
            [
                executable,
                "--voice",
                voice,
                "--rate=+4%",
                "--pitch=-2Hz",
                "--volume=+0%",
                "--text",
                text,
                "--write-media",
                str(destination),
            ],
            capture_output=True,
            text=True,
        )
        if (
            result.returncode == 0
            and destination.exists()
            and destination.stat().st_size > 1000
        ):
            return voice
        errors.append(f"{voice}: {result.stderr.strip() or 'sin audio'}")
    raise RuntimeError("No se pudo crear la voz neural. " + " | ".join(errors))


def make_segment(image_path: Path, audio_path: Path, destination: Path) -> None:
    speech_seconds = duration(audio_path)
    seconds = speech_seconds + 0.55
    fade_out = max(0.0, seconds - 0.35)
    audio_fade_out = max(0.0, seconds - 0.30)
    frames = max(1, math.ceil(seconds * FPS))
    video_filter = (
        "zoompan=z='min(zoom+0.00030,1.045)':"
        "x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
        f"d={frames}:s={WIDTH}x{HEIGHT}:fps={FPS},"
        "fade=t=in:st=0:d=0.25,"
        f"fade=t=out:st={fade_out:.2f}:d=0.32,"
        "eq=saturation=1.04,format=yuv420p"
    )
    audio_filter = (
        "apad=pad_dur=0.55,"
        "afade=t=in:st=0:d=0.10,"
        f"afade=t=out:st={audio_fade_out:.2f}:d=0.25"
    )
    run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-loop",
            "1",
            "-i",
            str(image_path),
            "-i",
            str(audio_path),
            "-vf",
            video_filter,
            "-af",
            audio_filter,
            "-t",
            f"{seconds:.2f}",
            "-r",
            str(FPS),
            "-c:v",
            "libx264",
            "-preset",
            "medium",
            "-crf",
            "20",
            "-c:a",
            "aac",
            "-b:a",
            "160k",
            "-ar",
            "44100",
            "-ac",
            "1",
            "-movflags",
            "+faststart",
            str(destination),
        ]
    )


def load_topic(topic_id: str) -> tuple[dict, list[str]]:
    catalog = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    selected = catalog["topics"].get(topic_id)
    if not selected:
        choices = ", ".join(sorted(catalog["topics"]))
        raise SystemExit(f"Tema desconocido: {topic_id}. Opciones: {choices}")
    return selected, catalog["palette"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--topic", default="ia_trabajo")
    args = parser.parse_args()

    topic, palette = load_topic(args.topic)
    if BUILD_DIR.exists():
        shutil.rmtree(BUILD_DIR)
    BUILD_DIR.mkdir(parents=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    segment_paths: list[Path] = []
    voices_used: list[str] = []
    for index, slide in enumerate(topic["slides"], start=1):
        slide_path = BUILD_DIR / f"slide-{index:02d}.jpg"
        audio_path = BUILD_DIR / f"voice-{index:02d}.mp3"
        segment_path = BUILD_DIR / f"segment-{index:02d}.mp4"
        make_slide(
            slide_path,
            slide,
            index,
            len(topic["slides"]),
            palette,
            seed=index * 991,
            topic_title=topic["title"],
            topic_tag=topic["tag"],
        )
        spoken_text = slide.get(
            "narration", f'{slide["heading"]}. {slide["body"]}'
        )
        if index == 1:
            spoken_text = f'{topic["intro"]} {spoken_text}'
        voices_used.append(narration(spoken_text, audio_path))
        make_segment(slide_path, audio_path, segment_path)
        segment_paths.append(segment_path)

    concat_file = BUILD_DIR / "segments.txt"
    concat_file.write_text(
        "".join(f"file '{path.resolve()}'\n" for path in segment_paths),
        encoding="utf-8",
    )
    final_video = OUTPUT_DIR / "short.mp4"
    run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(concat_file),
            "-c",
            "copy",
            "-movflags",
            "+faststart",
            str(final_video),
        ]
    )

    caption = (
        f'{topic["title"]}\n\n{topic["description"]}\n\n'
        + " ".join(topic["hashtags"])
    )
    (OUTPUT_DIR / "caption.txt").write_text(caption[:1000], encoding="utf-8")
    metadata = {
        "topic": args.topic,
        "title": topic["title"],
        "description": topic["description"],
        "hashtags": topic["hashtags"],
        "duration_seconds": round(duration(final_video), 2),
        "resolution": f"{WIDTH}x{HEIGHT}",
        "voices": sorted(set(voices_used)),
        "video": str(final_video),
    }
    (OUTPUT_DIR / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False))


if __name__ == "__main__":
    main()
