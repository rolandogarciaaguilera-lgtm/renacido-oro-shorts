#!/usr/bin/env python3
"""Genera un Short vertical, sin material con copyright, a partir de un catálogo."""

from __future__ import annotations

import argparse
import json
import math
import random
import shutil
import subprocess
import textwrap
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
CATALOG_PATH = ROOT / "catalog.json"
BUILD_DIR = ROOT / "build"
OUTPUT_DIR = ROOT / "output"
WIDTH, HEIGHT, FPS = 720, 1280, 30
FONT_REGULAR = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
FONT_BOLD = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")


def run(command: list[str]) -> None:
    subprocess.run(command, check=True)


def duration(path: Path) -> float:
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(path),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return float(result.stdout.strip())


def font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    if not path.exists():
        raise FileNotFoundError(f"No se encontró la fuente: {path}")
    return ImageFont.truetype(str(path), size=size)


def fit_lines(text: str, max_chars: int, max_lines: int) -> list[str]:
    lines = textwrap.wrap(
        text.strip(),
        width=max_chars,
        break_long_words=False,
        break_on_hyphens=False,
    )
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1].rstrip(" .") + "…"
    return lines


def draw_centered_lines(
    draw: ImageDraw.ImageDraw,
    lines: list[str],
    y: int,
    text_font: ImageFont.FreeTypeFont,
    fill: tuple[int, int, int],
    gap: int,
) -> int:
    for line in lines:
        box = draw.textbbox((0, 0), line, font=text_font)
        line_width = box[2] - box[0]
        draw.text(((WIDTH - line_width) / 2, y), line, font=text_font, fill=fill)
        y += (box[3] - box[1]) + gap
    return y


def make_slide(
    destination: Path,
    slide: dict,
    index: int,
    total: int,
    palette: list[str],
    seed: int,
) -> None:
    rng = random.Random(seed)
    top = tuple(int(palette[0][i : i + 2], 16) for i in (1, 3, 5))
    bottom = tuple(int(palette[1][i : i + 2], 16) for i in (1, 3, 5))
    accent = tuple(int(palette[2][i : i + 2], 16) for i in (1, 3, 5))

    image = Image.new("RGB", (WIDTH, HEIGHT))
    pixels = image.load()
    for y in range(HEIGHT):
        ratio = y / max(1, HEIGHT - 1)
        color = tuple(
            int(top[channel] * (1 - ratio) + bottom[channel] * ratio)
            for channel in range(3)
        )
        for x in range(WIDTH):
            pixels[x, y] = color

    overlay = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    overlay_draw = ImageDraw.Draw(overlay)
    for _ in range(18):
        radius = rng.randint(18, 95)
        x = rng.randint(-radius, WIDTH + radius)
        y = rng.randint(-radius, HEIGHT + radius)
        overlay_draw.ellipse(
            (x - radius, y - radius, x + radius, y + radius),
            fill=(*accent, rng.randint(10, 28)),
        )
    overlay_draw.rounded_rectangle(
        (42, 210, WIDTH - 42, 1045),
        radius=42,
        fill=(4, 10, 24, 188),
        outline=(*accent, 125),
        width=3,
    )
    image = Image.alpha_composite(image.convert("RGBA"), overlay)
    draw = ImageDraw.Draw(image)

    brand_font = font(FONT_BOLD, 27)
    label_font = font(FONT_BOLD, 21)
    small_font = font(FONT_BOLD, 25)
    heading_font = font(FONT_BOLD, 62)
    body_font = font(FONT_REGULAR, 39)

    draw.text((46, 54), "RENACIDO ORO", font=brand_font, fill=(255, 255, 255))
    label = "TECNOLOGÍA • OPORTUNIDADES REALES"
    label_box = draw.textbbox((0, 0), label, font=label_font)
    draw.text(
        ((WIDTH - (label_box[2] - label_box[0])) / 2, 112),
        label,
        font=label_font,
        fill=(*accent, 255),
    )

    badge = f"{index}/{total}"
    draw.rounded_rectangle((70, 250, 152, 305), radius=22, fill=(*accent, 235))
    draw.text((91, 263), badge, font=small_font, fill=(3, 8, 18))

    heading_lines = fit_lines(slide["heading"].upper(), 18, 4)
    body_lines = fit_lines(slide["body"], 30, 8)
    y = draw_centered_lines(
        draw, heading_lines, 365, heading_font, (255, 255, 255), 12
    )
    y += 50
    draw_centered_lines(draw, body_lines, y, body_font, (225, 234, 247), 15)

    footer = "Información educativa • verifica requisitos y disponibilidad"
    footer_font = font(FONT_REGULAR, 22)
    footer_box = draw.textbbox((0, 0), footer, font=footer_font)
    draw.text(
        ((WIDTH - (footer_box[2] - footer_box[0])) / 2, 1188),
        footer,
        font=footer_font,
        fill=(196, 207, 222),
    )
    image.convert("RGB").save(destination, quality=95)


def narration(slide: dict, destination: Path) -> None:
    text = f'{slide["heading"]}. {slide["body"]}'
    engine = shutil.which("espeak-ng") or shutil.which("espeak")
    if engine:
        run(
            [
                engine,
                "-v",
                "es",
                "-s",
                "148",
                "-p",
                "46",
                "-a",
                "175",
                "-w",
                str(destination),
                text,
            ]
        )
        return

    # Permite validar el generador en equipos sin motor de voz.
    silent_seconds = max(4.5, min(11.5, len(text.split()) / 2.15))
    run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "anullsrc=r=44100:cl=mono",
            "-t",
            f"{silent_seconds:.2f}",
            str(destination),
        ]
    )


def make_segment(image_path: Path, audio_path: Path, destination: Path) -> None:
    seconds = duration(audio_path) + 0.65
    fade_out = max(0.0, seconds - 0.35)
    frames = max(1, math.ceil(seconds * FPS))
    video_filter = (
        "scale=760:1352,"
        f"zoompan=z='min(zoom+0.00045,1.055)':"
        "x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
        f"d={frames}:s={WIDTH}x{HEIGHT}:fps={FPS},"
        "fade=t=in:st=0:d=0.30,"
        f"fade=t=out:st={fade_out:.2f}:d=0.30,format=yuv420p"
    )
    run(
        [
            "ffmpeg",
            "-y",
            "-loop",
            "1",
            "-i",
            str(image_path),
            "-i",
            str(audio_path),
            "-vf",
            video_filter,
            "-af",
            "apad=pad_dur=0.65",
            "-t",
            f"{seconds:.2f}",
            "-r",
            str(FPS),
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "25",
            "-c:a",
            "aac",
            "-b:a",
            "96k",
            "-ar",
            "44100",
            "-ac",
            "1",
            "-movflags",
            "+faststart",
            str(destination),
        ]
    )


def load_topic(topic_id: str) -> tuple[dict, list[str]]:
    catalog = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    topics = catalog["topics"]
    selected = topics.get(topic_id)
    if not selected:
        choices = ", ".join(sorted(topics))
        raise SystemExit(f"Tema desconocido: {topic_id}. Opciones: {choices}")
    return selected, catalog["palette"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--topic", default="ia_trabajo")
    args = parser.parse_args()

    topic, palette = load_topic(args.topic)
    if BUILD_DIR.exists():
        shutil.rmtree(BUILD_DIR)
    BUILD_DIR.mkdir(parents=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    segment_paths: list[Path] = []
    for index, slide in enumerate(topic["slides"], start=1):
        slide_path = BUILD_DIR / f"slide-{index:02d}.png"
        audio_path = BUILD_DIR / f"voice-{index:02d}.wav"
        segment_path = BUILD_DIR / f"segment-{index:02d}.mp4"
        make_slide(
            slide_path,
            slide,
            index,
            len(topic["slides"]),
            palette,
            seed=index * 991,
        )
        narration(slide, audio_path)
        make_segment(slide_path, audio_path, segment_path)
        segment_paths.append(segment_path)

    concat_file = BUILD_DIR / "segments.txt"
    concat_file.write_text(
        "".join(f"file '{path.resolve()}'\n" for path in segment_paths),
        encoding="utf-8",
    )
    final_video = OUTPUT_DIR / "short.mp4"
    run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(concat_file),
            "-c",
            "copy",
            "-movflags",
            "+faststart",
            str(final_video),
        ]
    )

    caption = (
        f'{topic["title"]}\n\n{topic["description"]}\n\n'
        + " ".join(topic["hashtags"])
    )
    (OUTPUT_DIR / "caption.txt").write_text(caption[:1000], encoding="utf-8")
    metadata = {
        "topic": args.topic,
        "title": topic["title"],
        "duration_seconds": round(duration(final_video), 2),
        "video": str(final_video),
    }
    (OUTPUT_DIR / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False))


if __name__ == "__main__":
    main()
