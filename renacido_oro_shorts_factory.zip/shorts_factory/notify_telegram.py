#!/usr/bin/env python3
"""Envía el video terminado y, si existe, su enlace de YouTube a Telegram."""

from __future__ import annotations

import json
import os
from pathlib import Path

import requests


ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "output"


def required(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"Falta el secreto {name}")
    return value


def main() -> None:
    token = required("TELEGRAM_BOT_TOKEN")
    chat_id = required("TELEGRAM_CHAT_ID")
    video_path = OUTPUT_DIR / "short.mp4"
    caption_path = OUTPUT_DIR / "caption.txt"
    if not video_path.exists():
        raise FileNotFoundError(video_path)

    caption = caption_path.read_text(encoding="utf-8") if caption_path.exists() else ""
    youtube_result = OUTPUT_DIR / "youtube_result.json"
    if youtube_result.exists():
        result = json.loads(youtube_result.read_text(encoding="utf-8"))
        caption = f'{caption}\n\nYouTube: {result["url"]}'

    url = f"https://api.telegram.org/bot{token}/sendVideo"
    with video_path.open("rb") as video:
        response = requests.post(
            url,
            data={
                "chat_id": chat_id,
                "caption": caption[:1024],
                "supports_streaming": "true",
            },
            files={"video": ("short.mp4", video, "video/mp4")},
            timeout=300,
        )
    response.raise_for_status()
    payload = response.json()
    if not payload.get("ok"):
        raise RuntimeError(payload)
    print("Video enviado a Telegram")


if __name__ == "__main__":
    main()
